package net.javaguides.springboot.springbootbackend.repository;

import net.javaguides.springboot.springbootbackend.model.SOW;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface SOWRepository extends JpaRepository<SOW, Long> {

    long countByBto(String btoName);
    List<SOW> getSowsByBto(String btoName);
}
