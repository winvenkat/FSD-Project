package net.javaguides.springboot.springbootbackend.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "sowsinq")
public class SOWsInQ {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "sownumber")
    private String sownumber;

    @Column(name = "type")
    private String type;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy")
    @Column(name = "startDate")
    private Date startDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy")
    @Column(name = "endDate")
    private Date endDate;

    @Column(name = "manager")
    private String manager;

    @Column(name = "bussarea")
    private String bussarea;

    @Column(name = "project")
    private String project;

    @Column(name = "severity")
    private String severity;

    @Column(name = "sowvalue")
    private String sowvalue;

    @Column(name = "portalnumber")
    private String portalnumber;

    @Column(name = "hc")
    private Integer hc;

    @Column(name = "status")
    private String status;

    @Column(name = "notes")
    private String notes;

}
