package net.javaguides.springboot.springbootbackend.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;


@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "cwname")
    private String cwname;

    @Column(name = "cwid")
    private String cwid;

    public Employee(long id, String cwname, String cwid, String sownumber, String project, String hexid, String isactive) {
        this.id = id;
        this.cwname = cwname;
        this.cwid = cwid;
        this.sownumber = sownumber;
        this.project = project;
        this.hexid = hexid;
        this.isactive = isactive;
    }

    public Employee(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Column(name = "sownumber")
    private String sownumber;

    @Column(name = "project")
    private String project;

    @Column(name = "hexid")
    private String hexid;

    public String getIsactive() {
        return isactive;
    }

    public void setIsactive(String isactive) {
        this.isactive = isactive;
    }

    @Column(name="IsActive")
    private String isactive;

    /*
    @Column(name = "role")
    private String role;

    @Column(name = "hexdm")
    private String hexdm;

    @Column(name = "phone")
    private String phone;

    @Column(name = "personalemail")
    private String personalemail;

    @Column(name = "fmemail")
    private String fmemail;

    @Column(name = "remarks")
    private String remarks;*/

    @Override
    public String toString() {
        return "Employee{" +
                "sownumber='" + sownumber + '\'' +
                '}';
    }
}

