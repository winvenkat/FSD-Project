package net.javaguides.springboot.springbootbackend.controller;

import net.javaguides.springboot.springbootbackend.model.Employee;
import net.javaguides.springboot.springbootbackend.model.SOW;
import net.javaguides.springboot.springbootbackend.model.SOWsInQ;
import net.javaguides.springboot.springbootbackend.repository.SOWsInQRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/inq-sows")
public class SOWInQController {
    @Autowired
    private SOWsInQRepository sowsinqRepository;

    @GetMapping
    public List<SOWsInQ> getSOWsInQList(){
        return sowsinqRepository.findAll();
    }
    @GetMapping("{severity}")
    public List<SOWsInQ> findBySeverity(@PathVariable("severity") String severity) {
        return sowsinqRepository.findBySeverity(severity);
    }

}
