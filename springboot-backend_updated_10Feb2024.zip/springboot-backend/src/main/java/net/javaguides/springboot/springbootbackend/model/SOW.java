package net.javaguides.springboot.springbootbackend.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.Entity;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "sows")
public class SOW {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "sownumber")
    private String sownumber;

    @Column(name = "project")
    private String project;

    @Column(name = "manager")
    private String manager;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy")
    @Column(name = "endDate")
    private Date endDate;

    @Column(name = "hc")
    private Integer hc;

    public String getIsactive() {
        return isactive;
    }

    public void setIsactive(String isactive) {
        this.isactive = isactive;
    }

    @Column(name = "milestones")
    private Integer milestones;

    @Column(name="billtype")
    private String billtype;

    @Column(name="bto")
    private String bto;

    @Column(name="IsActive")
    private String isactive;
}
