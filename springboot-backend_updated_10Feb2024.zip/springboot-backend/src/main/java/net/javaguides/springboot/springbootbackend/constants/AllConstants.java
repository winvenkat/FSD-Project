package net.javaguides.springboot.springbootbackend.constants;

public final class  AllConstants {

    private AllConstants() {
        // restrict instantiation
    }
    public static final String SF_BTO="SF";
    public static final String MF_BTO="MF";
    public static final String Factory_BTO="Factory";
    public static final String Infra_BTO="Infra";
    public static final String InfoSec_BTO="InfoSec";
    public static final String OTHER_BTO="Other";



}
