package net.javaguides.springboot.springbootbackend.service;

import net.javaguides.springboot.springbootbackend.exception.ResourceNotFoundException;
import net.javaguides.springboot.springbootbackend.model.SOW;
import net.javaguides.springboot.springbootbackend.repository.EmployeeRepository;
import net.javaguides.springboot.springbootbackend.repository.SOWRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Service
public class SOWService {

    @Autowired
    private SOWRepository sowRepository;

    @Autowired
    private EmployeeRepository employeeRepository;



    public List<SOW> getSOWsList(){
        return sowRepository.findAll();
    }


    public List<SOW> getSOWsByBto(@PathVariable String btoName){
        return sowRepository.getSowsByBto(btoName);
    }

    public long getSOWsCountByBto(String btoName){
        long sowsCnt=0;
        if(btoName.equals("ALL")){
            sowsCnt=sowRepository.count();
        }
        else if(btoName.equals("Others")){
            sowsCnt=sowRepository.countByBto("Factory")+sowRepository.countByBto("Infra")+
                    sowRepository.countByBto("ICM")+sowRepository.countByBto("Business")+
                    sowRepository.countByBto("Infosec")+sowRepository.countByBto("EOT");
        }
        else{
            sowsCnt=sowRepository.countByBto(btoName);
        }

        return sowsCnt;
    }
    @GetMapping("/{id}")
    public ResponseEntity<SOW> getEmployeeById(@PathVariable  long id){
        SOW sow = sowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SOW not exist with id:" + id));
        return ResponseEntity.ok(sow);
    }
    @GetMapping("/sows/{id}")
    public ResponseEntity<SOW> getSOW(@PathVariable("id")  long id){
        SOW sow=sowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SOW not exist with id:" + id));
        return ResponseEntity.ok(sow);
    }

    @PostMapping("/addsow")
    public SOW addSOW(@RequestBody SOW sow) {
        return sowRepository.save(sow);
    }

    @PutMapping("/sows/{id}")
    public ResponseEntity<SOW> editSOW(@PathVariable long id,@RequestBody SOW sow) {
        SOW editSOW = sowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SOW not exist with id: " + id));

        editSOW.setSownumber(sow.getSownumber());
        editSOW.setProject(sow.getProject());
        editSOW.setManager(sow.getManager());
        editSOW.setEndDate(sow.getEndDate());
        editSOW.setBilltype(sow.getBilltype());
        editSOW.setBto(sow.getBto());
        editSOW.setHc(sow.getHc());

        sowRepository.save(editSOW);

        return ResponseEntity.ok(editSOW);
    }


}
