package net.javaguides.springboot.springbootbackend.repository;


import net.javaguides.springboot.springbootbackend.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // all crud database methods

    List<Employee> findBySownumber(String sownumber);
    Employee findByCwid(String cwid);
    Optional<Employee> findById(Integer id);
}