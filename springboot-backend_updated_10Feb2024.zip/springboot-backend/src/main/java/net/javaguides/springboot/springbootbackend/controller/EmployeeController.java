package net.javaguides.springboot.springbootbackend.controller;

import net.javaguides.springboot.springbootbackend.exception.ResourceNotFoundException;
import net.javaguides.springboot.springbootbackend.model.Employee;
import net.javaguides.springboot.springbootbackend.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin("*")
@RestController
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/emplist")
    public List<Employee> getAllEmployees(){
        return employeeRepository.findAll();
    }

    @RequestMapping("{cwid}")
    public Employee findByCwid(@PathVariable("cwid") String cwid){
        return employeeRepository.findByCwid(cwid);
    }

    // build create employee REST API
    @PostMapping
    public Employee createEmployee(@RequestBody Employee employee) {
        return employeeRepository.save(employee);
    }

    // build get employee by id REST API
    @GetMapping("/emplist/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable("id")  long id){
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id:" + id));
        return ResponseEntity.ok(employee);
    }

    // build update employee REST API
    @PutMapping("{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable long id,@RequestBody Employee employeeDetails) {
        Employee updateEmployee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id: " + id));

        updateEmployee.setCwid(employeeDetails.getCwid());
        updateEmployee.setCwname(employeeDetails.getCwname());
        updateEmployee.setSownumber(employeeDetails.getSownumber());
        updateEmployee.setProject(employeeDetails.getProject());


        employeeRepository.save(updateEmployee);

        return ResponseEntity.ok(updateEmployee);
    }

    // build delete employee REST API
    @DeleteMapping("{id}")
    public ResponseEntity<HttpStatus> deleteEmployee(@PathVariable long id){
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id: " + id));

        //employeeRepository.delete(employee);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }
}