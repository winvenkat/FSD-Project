package net.javaguides.springboot.springbootbackend.controller;
import net.javaguides.springboot.springbootbackend.constants.AllConstants;
import net.javaguides.springboot.springbootbackend.exception.ResourceNotFoundException;
import net.javaguides.springboot.springbootbackend.model.Employee;
import net.javaguides.springboot.springbootbackend.model.SOW;
import net.javaguides.springboot.springbootbackend.repository.EmployeeRepository;
import net.javaguides.springboot.springbootbackend.repository.SOWRepository;
import net.javaguides.springboot.springbootbackend.service.SOWService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@CrossOrigin("*")
@RestController
public class SOWController {

    @Autowired
    private SOWService sowService;

    private HashMap<String, Long> sowsCntByBto = new HashMap<String, Long>();

    @GetMapping("/sows")
    public List<SOW> getSOWsList(){
        return sowService.getSOWsList();
    }

    @GetMapping("/sows/bto/{btoName}")
    public List<SOW>  getSOWsByBto(@PathVariable String btoName){
        return sowService.getSOWsByBto(btoName);
    }
    @GetMapping("/sows/btoCount/{btoName}")
    public long getSOWsCountByBto(@PathVariable String btoName){
        long sowsCnt=sowService.getSOWsCountByBto(btoName);
        return sowsCnt;
    }
    @GetMapping("/sows/{id}")
    public ResponseEntity<SOW> getSOW(@PathVariable("id")  long id){
        return sowService.getSOW(id);
    }

    @PostMapping("/sows/addsow")
    public SOW addSOW(@RequestBody SOW sow) {
        return sowService.addSOW(sow);
    }

    @PutMapping("/sows/{id}")
    public ResponseEntity<SOW> editSOW(@PathVariable long id,@RequestBody SOW sow) {

        return sowService.editSOW(id,sow);
    }

  /*  public long storeSowCntByBto(String bto){
        sowsCntByBto.put(AllConstants.SF_BTO,sowService)
    }*/

}
