package net.javaguides.springboot.springbootbackend.controller;
import net.javaguides.springboot.springbootbackend.exception.ResourceNotFoundException;
import net.javaguides.springboot.springbootbackend.model.Employee;
import net.javaguides.springboot.springbootbackend.model.SOW;
import net.javaguides.springboot.springbootbackend.repository.EmployeeRepository;
import net.javaguides.springboot.springbootbackend.repository.SOWRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/sows")
public class SOWController {
    @Autowired
    private SOWRepository sowRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping
    public List<SOW> getSOWsList(){
        return sowRepository.findAll();
    }

    @GetMapping("{id}")
    public ResponseEntity<SOW> getEmployeeById(@PathVariable  long id){
        SOW sow = sowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SOW not exist with id:" + id));
        return ResponseEntity.ok(sow);
    }
    @GetMapping("/sows/{id}")
    public ResponseEntity<SOW> getSOW(@PathVariable("id")  long id){
        SOW sow=sowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SOW not exist with id:" + id));
        return ResponseEntity.ok(sow);
    }

    @PostMapping
    public SOW addSOW(@RequestBody SOW sow) {
        return sowRepository.save(sow);
    }

    @PutMapping("{id}")
    public ResponseEntity<SOW> editSOW(@PathVariable long id,@RequestBody SOW sow) {
        SOW editSOW = sowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SOW not exist with id: " + id));

        editSOW.setSownumber(sow.getSownumber());
        editSOW.setProject(sow.getProject());
        editSOW.setManager(sow.getManager());
        editSOW.setEndDate(sow.getEndDate());
        editSOW.setBilltype(sow.getBilltype());
        editSOW.setBto(sow.getBto());
        editSOW.setHc(sow.getHc());

        sowRepository.save(editSOW);

        return ResponseEntity.ok(editSOW);
    }


}
