package net.javaguides.springboot.springbootbackend;

import net.javaguides.springboot.springbootbackend.model.Employee;
import net.javaguides.springboot.springbootbackend.repository.EmployeeRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@SpringBootApplication
@ComponentScan(basePackages ={ "net.javaguides.springboot.springbootbackend.*" })
public class SpringbootBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootBackendApplication.class, args);
		/*ConfigurableApplicationContext ctxt=SpringApplication.run(SpringbootBackendApplication.class, args);
		EmployeeRepository bean=ctxt.getBean(EmployeeRepository.class);
		List<Employee> emplist=bean.findBySownumber("M13033-3680");
		System.out.println("Result=="+emplist.get(1).getCwname());*/
	}

}
