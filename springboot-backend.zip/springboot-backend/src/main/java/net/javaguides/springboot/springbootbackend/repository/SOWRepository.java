package net.javaguides.springboot.springbootbackend.repository;

import net.javaguides.springboot.springbootbackend.model.SOW;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SOWRepository extends JpaRepository<SOW, Long> {

}
