package net.javaguides.springboot.springbootbackend.controller;

import net.javaguides.springboot.springbootbackend.exception.ResourceNotFoundException;
import net.javaguides.springboot.springbootbackend.model.Employee;
import net.javaguides.springboot.springbootbackend.model.Milestones;
import net.javaguides.springboot.springbootbackend.repository.MilestonesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/milestones")
public class MilestonesController {
    @Autowired
    private MilestonesRepository milestonesRepository;

    @GetMapping
    public List<Milestones> getMilestonesList(){
        return milestonesRepository.findAll();
    }
    @RequestMapping(path="/milestones/{id}")
    public ResponseEntity<Milestones> getMilestonesById(@PathVariable long id){
        Milestones milestones = milestonesRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SOW not exist with id:" + id));
        return ResponseEntity.ok(milestones);
    }

    @GetMapping("{sownumber}")
    public List<Milestones> findBySownumber(@PathVariable("sownumber") String sownumber) {
        return milestonesRepository.findBySownumber(sownumber);
    }
}
