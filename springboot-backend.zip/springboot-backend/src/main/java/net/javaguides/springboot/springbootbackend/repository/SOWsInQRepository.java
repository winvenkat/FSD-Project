package net.javaguides.springboot.springbootbackend.repository;

import net.javaguides.springboot.springbootbackend.model.Employee;
import net.javaguides.springboot.springbootbackend.model.SOW;
import net.javaguides.springboot.springbootbackend.model.SOWsInQ;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SOWsInQRepository extends JpaRepository<SOWsInQ, Long> {

    List<SOWsInQ> findBySeverity(String severity);
}
