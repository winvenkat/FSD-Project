package net.javaguides.springboot.springbootbackend.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "milestones")
public class Milestones {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "sownumber")
    private String sownumber;

    @Column(name = "project")
    private String project;

    @Column(name = "approver")
    private String approver;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy")
    @Column(name = "submittedDate")
    private Date submittedDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy")
    @Column(name = "approvedDate")
    private Date approvedDate;

    @Column(name = "msvalue")
    private Double msvalue;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MMM-yyyy")
    @Column(name = "msmonth")
    private Date msmonth;

    @Column(name = "projectid")
    private Integer projectid;

    @Column(name = "msstatus")
    private String msstatus;

    @Column(name = "remarks")
    private String remarks;

}







