package net.javaguides.springboot.springbootbackend.repository;

import net.javaguides.springboot.springbootbackend.model.Milestones;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MilestonesRepository extends JpaRepository<Milestones, Long> {

    List<Milestones> findBySownumber(String sownumber);
}
