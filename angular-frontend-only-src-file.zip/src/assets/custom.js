function demoJs(){
    alert('Welcome to my Dashboard !!!')
}
function countTableRows(){
    var x = document.getElementById("myTable").rows.length;
    return x;
}