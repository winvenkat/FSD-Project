import { Component, OnInit } from '@angular/core';
import { SowService } from "../sow.service";
import { EmployeeService } from "../employee.service";
import { Observable, map } from 'rxjs';
import { SOW } from '../sow';
import { Employee } from '../employee';
declare function demoJs(): any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],     
})
export class HomeComponent implements OnInit { 
  
  activesows!: Observable<SOW[]>;
  sffows!: Observable<SOW[]>;
  mfsows!: Observable<SOW[]>;  
  othersows!: Observable<SOW[]>;
  sowsArr:Array<SOW>=[];
  sfsowsArrOutput:Array<SOW>=[];  
  mfsowsArrOutput:Array<SOW>=[];  
  othersowsArrOutput:Array<SOW>=[];  
  totalemps!: Observable<Employee[]>;
  btoValue!:string;  
  sfbto:string='SF';
  mfbto:string='MF'; 

  constructor(private sowService:SowService,private empService: EmployeeService) { }

  ngOnInit():void { 
    //demoJs(); 
    this.activesows=this.sowService.getSOWsList();    
    this.totalemps = this.empService.getEmployeesList();   
    this.activesows=this.activesows.pipe( 
      map(arr =>
        arr.filter( r =>  r.isactive.includes('Yes'))
      )
    )         
    this.sffows=this.activesows.pipe( 
      map(arr =>
        arr.filter( r =>  r.bto.includes('SF') && r.isactive.includes('Yes'))
      )
    )
    this.mfsows=this.activesows.pipe( 
      map(arr =>
        arr.filter( r =>  r.bto.includes('MF') && r.isactive.includes('Yes'))
      )
    )         
    this.othersows=this.activesows.pipe( 
      map(arr =>
        arr.filter( r =>  r.bto.includes('Infra') ||r.bto.includes('ICM')||r.bto.includes('Infosec')||r.bto.includes('EOT')||r.bto.includes('Factory') || r.bto.includes('Business') && r.isactive.includes('Yes'))
      )
    )  
    this.activesows.subscribe(data => {
      this.sowsArr = data;                 
    });  
    
} // end of ngOnInit

getSFSOWs(bto:string){
  
  console.log("Inside of getSFSOWs "+bto);
  console.log("sfsowsArr length::"+this.sowsArr.length)        
  for (let item of this.sowsArr) {
    switch(item.bto){
      case this.sfbto:
        this.sfsowsArrOutput.push(item);
        break;
      case this.mfbto:
        this.mfsowsArrOutput.push(item);
        break;
      
      default:
        this.othersowsArrOutput.push(item);
        break;     
    }     
 }//end of for
 console.log("sfsowsArrOutput::=> "+this.sfsowsArrOutput.length)
 console.log("mfsowsArrOutput::=> "+this.mfsowsArrOutput.length)
 console.log("othersowsArrOutput::=> "+this.othersowsArrOutput.length)
 //return this.sfsowsArrOutput;
}
}