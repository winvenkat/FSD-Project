import { TestBed } from '@angular/core/testing';

import { SowService } from './sow.service';

describe('SowService', () => {
  let service: SowService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SowService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
