import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSOWComponent } from './add-sow.component';

describe('AddSOWComponent', () => {
  let component: AddSOWComponent;
  let fixture: ComponentFixture<AddSOWComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddSOWComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddSOWComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
