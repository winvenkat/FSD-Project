import { Component, OnInit } from '@angular/core';
import { SowService } from '../sow.service';
import { SOW } from '../sow';
import { Router } from '@angular/router';
import { FormBuilder,FormGroup,Validators  } from '@angular/forms';

@Component({
  selector: 'app-add-sow',
  templateUrl: './add-sow.component.html',
  styleUrls: ['./add-sow.component.css']
})
export class AddSOWComponent implements OnInit {

  sow: SOW = new SOW();
  submitted = false;
  addSOWForm: FormGroup=new FormGroup({});

  constructor(private sowService: SowService,
    private router: Router,private formBuilder: FormBuilder,) { }

  ngOnInit(): void {    
    this.addSOWForm = this.formBuilder.group({
      sownumber: ['', Validators.required],
      project: ['', Validators.required],
      manager: ['', Validators.required],
      endDate: ['', [Validators.required]],
      hc: ['', Validators.required],      
      billtype:['',Validators.required],
      bto:['',Validators.required],
    })
  }
  addSOW(): void {
    this.submitted = false;
    this.sow = new SOW();
    this.sow.isactive="Yes";
  }

  save() {
    this.sowService
    .addSOW(this.sow).subscribe(data => {
      console.log(data)
      this.sow = new SOW();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    console.log("Inside OnSubmit()")
    if(this.addSOWForm.valid){
      console.log("Valid form !!")
      this.submitted = true;
      this.save();  
    }
    else{
      console.log("Not a Valid form !!")
    }
      
  }

  gotoList() {
    this.router.navigate(['/sows']);
  }

}
