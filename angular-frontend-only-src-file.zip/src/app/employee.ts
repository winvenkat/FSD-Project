export class Employee {
    id!: number;
    cwname!: string;
    cwid!:string;
    sownumber!: string;
    project!: string;
    hexid!: boolean;
}