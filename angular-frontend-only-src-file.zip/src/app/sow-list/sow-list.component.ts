import { Component, OnInit } from '@angular/core';
import { SowService } from "../sow.service";
import { Observable } from "rxjs";
import { SOW } from "../sow";
import { Router } from '@angular/router';
import { pipe } from 'rxjs'; 
import { map, filter } from 'rxjs/operators';
declare function countTableRows(): any;
@Component({  
  selector: 'app-sow-list',
  templateUrl: './sow-list.component.html',
  styleUrls: ['./sow-list.component.css']
  
})
export class SowListComponent implements OnInit {

  activesows!: Observable<SOW[]>;  
  filteredSOWs!:Observable<SOW[]>;  
  groupedSOWs!:  Observable<SOW[]>;  
  totalRows!:number;
  btoCount!:number;  
  btoName!:string;
  
  constructor(private sowService: SowService,
    private router: Router) { }

    showDiv = {
      sf : false,
      mf : false,
      others : false,
      all:true,     
    }
    ngOnInit() {
      this.reloadData(); 
    }
   
    sows(id: number){
      this.router.navigate(['sows', id]);
    }

    empListBySow(sownumber:string){
      this.router.navigate(['employees',sownumber])
    }
    reloadData() {
      this.activesows = this.sowService.getSOWsList();       
      this.filteredSOWs=this.sowService.getSOWsList();   
      this.groupedSOWs=this.sowService.getSOWsByBto('SF');
      this.sowService.getSOWCountByBTO('ALL').subscribe(
        (value: number) => {
          this.btoCount = value;          
        },
        (error) => {
          console.error('Error fetching integer value from API:', error);
        }
      );                 
    } 
    getButtonTextBTO(btoName:string){
      this.sowService.getSOWCountByBTO(btoName).subscribe(
        (value: number) => {
          this.btoCount = value;          
        },
        (error) => {
          console.error('Error fetching integer value from API:', error);
        }
      );  
    }
    applyFilter(event: Event) {
      let filterValue = (event.target as HTMLInputElement).value;
      filterValue=filterValue.toLowerCase();    
      console.log(filterValue)
      this.filteredSOWs=this.activesows.pipe( 
        map(arr =>
          arr.filter( r => r.project.toLowerCase().includes(filterValue) || r.sownumber.includes(filterValue))
        )
      )   
      
    }
}
