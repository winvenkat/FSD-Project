import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SowListComponent } from './sow-list.component';

describe('SowListComponent', () => {
  let component: SowListComponent;
  let fixture: ComponentFixture<SowListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SowListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SowListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
