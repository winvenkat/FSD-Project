import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { SowListComponent } from './sow-list/sow-list.component';
import { SowHomeComponent } from './sow-home/sow-home.component';
import { HomeComponent } from './home/home.component';
import { AddSOWComponent } from './add-sow/add-sow.component';

const routes: Routes = [
  //{ path: '', redirectTo: 'employee', pathMatch: 'full' },
  { path: '', component:HomeComponent},  
  { path: 'employees', component: EmployeeListComponent },
  { path: 'add', component: CreateEmployeeComponent },
  { path: 'update-employee/:id', component: UpdateEmployeeComponent },
  { path: 'empDetails/:id', component: EmployeeDetailsComponent },
  { path: 'sows', component: SowListComponent },
  { path: 'sows/:id', component: SowHomeComponent },
  { path: 'employees/:sow', component: EmployeeListComponent },
  { path: 'addsow',component:AddSOWComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }