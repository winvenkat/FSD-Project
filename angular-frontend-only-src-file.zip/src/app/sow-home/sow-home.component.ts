import { Component, OnInit } from '@angular/core';
import { SowService } from "../sow.service";
import { ActivatedRoute, Router } from '@angular/router';
import { SOW } from '../sow';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-sow-home',
  templateUrl: './sow-home.component.html',
  styleUrls: ['./sow-home.component.css'],
  providers: [DatePipe]

})

export class SowHomeComponent implements OnInit {

  sowDetail!: SOW;
  id!: number;
  sownumber!: string;
  project!: string;
  constructor(public datepipe: DatePipe,private sowService: SowService,private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(){
    this.sowDetail = new SOW();    
    this.id = this.route.snapshot.params['id'];  
    console.log(this.id)  
    this.sowService.getSOW(this.id)
      .subscribe(data => {
        console.log(data)
        this.sowDetail = data;
      })
  } 
  onSubmit(){
    console.log("EndDate is ==> "+this.sowDetail.endDate)
    this.updateSOWDetail();
  }
  updateSOWDetail() {
    this.sowService.editSOW(this.id, this.sowDetail)
      .subscribe(data => {
        console.log(data);
        this.sowDetail = new SOW();
        this.gotoList();
      });
  }
  gotoList() {
    this.router.navigate(['/sows']);
  }

  SendDatetoFunction(event: any) {
    let enddate=event.target.value;
    console.log("Before "+enddate);
    enddate=this.datepipe.transform(enddate, 'dd-MMM-yyyy')
    console.log("After "+enddate)
    this.sowDetail.endDate=enddate;
  }
}
