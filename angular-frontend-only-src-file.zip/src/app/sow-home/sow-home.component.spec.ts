import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SowHomeComponent } from './sow-home.component';

describe('SowHomeComponent', () => {
  let component: SowHomeComponent;
  let fixture: ComponentFixture<SowHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SowHomeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SowHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
