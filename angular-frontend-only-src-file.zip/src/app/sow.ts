export class SOW {
    id!: number;
    sownumber!: string;
    project!: string;
    manager!: string;    
    endDate!:Date;
    hc!: number;
    billtype!:string;
    bto!:string;
    isactive!:string;
}