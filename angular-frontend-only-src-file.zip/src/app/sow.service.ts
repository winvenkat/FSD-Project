import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable,count,filter,from } from 'rxjs';
import { SOW } from './sow';

@Injectable({
  providedIn: 'root'
})
export class SowService {

  private baseUrl = 'http://localhost:8080/sows';
  private baseUrl1 = 'http://localhost:8080/sows/bto';  
  private baseUrl2 = 'http://localhost:8080/sows/btoCount'; 
  //private isactive='Yes';

  activesows!: Observable<SOW[]>;
  sffows!: Observable<SOW[]>;
  mfsows!: Observable<SOW[]>;
  btoName!:String;
  constructor(private http: HttpClient) { }

  getSOWsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  } 

  getSOWsByBto(btoName:String): Observable<any> {
    return this.http.get(`${this.baseUrl1}/${this.btoName}`);
  } 
 /* getSOWsActive(): Observable<any> {
    return this.http.get(`${this.baseUrl}/${this.isactive}`);
  }*/ 
  getSOW(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }
  
  editSOW(id: number, value: any): Observable<Object> {    
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }
  addSOW(sow: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, sow);
  } 
  getSOWCountByBTO(btoName:string): Observable<number> {
    return this.http.get<number>(`${this.baseUrl2}/${btoName}`);
  }
  
}
