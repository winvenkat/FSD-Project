import { EmployeeDetailsComponent } from '../employee-details/employee-details.component';
import { Observable } from "rxjs";
import { EmployeeService } from "../employee.service";
import { Employee } from "../employee";
import { Component, OnInit } from "@angular/core";
import { Router } from '@angular/router';
import { pipe } from 'rxjs'; 
import { map, filter } from 'rxjs/operators';

@Component({
  selector: "app-employee-list",
  templateUrl: "./employee-list.component.html",
  styleUrls: ["./employee-list.component.css"]
})
export class EmployeeListComponent implements OnInit {
  
  employees!: Observable<Employee[]>;
  empsbysow!: Observable<Employee[]>;
  filteredEmployees!:Observable<Employee[]>;

  constructor(private employeeService: EmployeeService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.employees = this.employeeService.getEmployeesList();
    this.filteredEmployees= this.employeeService.getEmployeesList();
  }

  deleteEmployee(id: number) {
    this.employeeService.deleteEmployee(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  employeeDetails(id: number){
    this.router.navigate(['empDetails', id]);
  }
  updateEmployee(id: number){
    this.router.navigate(['update-employee', id]);
  }
  applyFilter(event: Event) {
    let filterValue = (event.target as HTMLInputElement).value;
    filterValue=filterValue.toLowerCase();    
    console.log(filterValue)
    this.filteredEmployees=this.employees.pipe( 
      map(arr =>
        arr.filter( r => r.cwname.toLowerCase().includes(filterValue) || r.cwid.toLowerCase().includes(filterValue) ||r.project.toLowerCase().includes(filterValue) ||r.sownumber.toLowerCase().includes(filterValue))
      )
    )   
    
  }
  
}